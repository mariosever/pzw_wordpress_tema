<?php /* Template Name: Blog page */ ?>

<?php get_header(); ?>



<?php wp_footer(); ?>

</body>
</html>